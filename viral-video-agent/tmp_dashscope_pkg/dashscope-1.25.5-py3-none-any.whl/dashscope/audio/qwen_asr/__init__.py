# Copyright (c) Alibaba, Inc. and its affiliates.

from .qwen_transcription import (QwenTranscription)

__all__ = [
    'QwenTranscription',
]
