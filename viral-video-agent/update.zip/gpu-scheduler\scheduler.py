"""
GPU 服务调度器 - 自动管理 CosyVoice 和 Duix 服务的启停

由于 Tesla P4 只有 8GB 显存，无法同时运行两个服务，
此调度器会根据任务类型自动切换服务。
"""

import os
import time
import subprocess
import asyncio
import threading
import shlex
import shutil
from queue import Queue
from typing import Optional, Literal
from dataclasses import dataclass
from datetime import datetime
import logging
import httpx
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# 配置
COSYVOICE_DIR = os.environ.get('COSYVOICE_DIR', '/root/viral-video-agent/scripts/deploy/cosyvoice')
DUIX_DIR = os.environ.get('DUIX_DIR', '/root/viral-video-agent/scripts/deploy/duix')
COSYVOICE_URL = os.environ.get('COSYVOICE_URL', 'http://localhost:9090')
DUIX_URL = os.environ.get('DUIX_URL', 'http://localhost:8383')
SERVICE_SWITCH_TIMEOUT = int(os.environ.get('SERVICE_SWITCH_TIMEOUT', '120'))  # 秒

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

ServiceType = Literal['cosyvoice', 'duix', None]

@dataclass
class TaskInfo:
    id: str
    service: ServiceType
    status: str  # 'queued' | 'switching' | 'processing' | 'done' | 'error'
    created_at: datetime
    message: Optional[str] = None

class GPUScheduler:
    def __init__(self):
        self.current_service: ServiceType = None
        self.lock = threading.Lock()
        self.task_queue: Queue[TaskInfo] = Queue()
        self.current_task: Optional[TaskInfo] = None
        self.switching = False

        # Prefer legacy docker-compose for older Docker; fall back to docker compose plugin if present.
        if shutil.which('docker-compose'):
            self.compose_cmd = ['docker-compose']
        elif shutil.which('docker'):
            self.compose_cmd = ['docker', 'compose']
        else:
            self.compose_cmd = ['docker-compose']
    
    def _run_docker_compose(self, directory: str, command: str) -> bool:
        """执行 docker compose 命令"""
        try:
            # 先尝试新版 docker compose，失败则用旧版 docker-compose
            args = shlex.split(command)
            cmd = [*self.compose_cmd, *args]
            result = subprocess.run(
                cmd,
                cwd=directory,
                capture_output=True,
                text=True,
                timeout=120
            )
            if result.returncode != 0:
                logger.error(f"Docker compose failed: {' '.join(cmd)}\nstdout: {result.stdout}\nstderr: {result.stderr}")
                return False
            return True
        except Exception as e:
            logger.error(f"Docker compose error: {e}")
            return False
    
    def _wait_for_service(self, service: ServiceType, timeout: int = 60) -> bool:
        """等待服务就绪"""
        url = COSYVOICE_URL if service == 'cosyvoice' else DUIX_URL
        health_endpoint = f"{url}/health" if service == 'cosyvoice' else f"{url}/easy/query?code=health_check"
        
        start = time.time()
        while time.time() - start < timeout:
            try:
                with httpx.Client(timeout=5) as client:
                    resp = client.get(health_endpoint)
                    if resp.status_code < 500:
                        logger.info(f"Service {service} is ready")
                        return True
            except Exception:
                pass
            time.sleep(2)
        
        logger.warning(f"Service {service} not ready after {timeout}s")
        return False
    
    def switch_to_service(self, target: ServiceType) -> bool:
        """切换到目标服务"""
        with self.lock:
            if self.current_service == target:
                logger.info(f"Already running {target}")
                return True
            
            self.switching = True
            logger.info(f"Switching from {self.current_service} to {target}")
            
            # 停止当前服务
            if self.current_service == 'cosyvoice':
                logger.info("Stopping CosyVoice...")
                self._run_docker_compose(COSYVOICE_DIR, 'stop')
                time.sleep(5)  # 等待显存释放
            elif self.current_service == 'duix':
                logger.info("Stopping Duix...")
                self._run_docker_compose(DUIX_DIR, 'stop')
                time.sleep(5)
            
            # 启动目标服务
            if target == 'cosyvoice':
                logger.info("Starting CosyVoice...")
                if not self._run_docker_compose(COSYVOICE_DIR, 'up -d'):
                    self.switching = False
                    return False
            elif target == 'duix':
                logger.info("Starting Duix...")
                if not self._run_docker_compose(DUIX_DIR, 'up -d'):
                    self.switching = False
                    return False
            
            # 等待服务就绪
            if not self._wait_for_service(target, SERVICE_SWITCH_TIMEOUT):
                self.switching = False
                return False
            
            self.current_service = target
            self.switching = False
            logger.info(f"Successfully switched to {target}")
            return True
    
    def get_status(self) -> dict:
        """获取调度器状态"""
        return {
            "current_service": self.current_service,
            "switching": self.switching,
            "queue_size": self.task_queue.qsize(),
        }

# 全局调度器实例
scheduler = GPUScheduler()

# FastAPI 应用
app = FastAPI(title="GPU Service Scheduler", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health():
    return {"status": "ok", "scheduler": scheduler.get_status()}

@app.get("/status")
async def status():
    return scheduler.get_status()

@app.post("/switch/{service}")
async def switch_service(service: str):
    """手动切换服务"""
    if service not in ['cosyvoice', 'duix']:
        raise HTTPException(400, "Invalid service. Use 'cosyvoice' or 'duix'")
    
    if scheduler.switching:
        raise HTTPException(503, "Service switching in progress, please wait")
    
    success = scheduler.switch_to_service(service)
    if not success:
        raise HTTPException(500, f"Failed to switch to {service}")
    
    return {"success": True, "current_service": service}

# ========== CosyVoice 代理 ==========

@app.api_route("/v1/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def proxy_cosyvoice(path: str, request: Request):
    """代理 CosyVoice 请求"""
    # 自动切换到 CosyVoice
    if scheduler.current_service != 'cosyvoice':
        if scheduler.switching:
            return JSONResponse({"error": "Service switching in progress"}, status_code=503)
        
        success = scheduler.switch_to_service('cosyvoice')
        if not success:
            return JSONResponse({"error": "Failed to start CosyVoice"}, status_code=500)
    
    # 转发请求
    url = f"{COSYVOICE_URL}/v1/{path}"
    
    async with httpx.AsyncClient(timeout=300) as client:
        try:
            body = await request.body()
            resp = await client.request(
                method=request.method,
                url=url,
                content=body,
                headers={k: v for k, v in request.headers.items() if k.lower() not in ['host']},
                params=request.query_params,
            )
            return JSONResponse(resp.json() if resp.headers.get('content-type', '').startswith('application/json') else {"data": resp.text}, status_code=resp.status_code)
        except Exception as e:
            logger.error(f"CosyVoice proxy error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

# ========== Duix 上传代理（/upload）==========

@app.api_route("/upload", methods=["POST"])
async def proxy_upload(request: Request, background_tasks: BackgroundTasks):
    """代理 Duix 上传（避免前端直连 8383）"""
    if scheduler.current_service != 'duix':
        if scheduler.switching:
            return JSONResponse({"error": "Service switching in progress"}, status_code=503)

        success = scheduler.switch_to_service('duix')
        if not success:
            return JSONResponse({"error": "Failed to start Duix"}, status_code=500)

    url = f"{DUIX_URL}/upload"

    client = httpx.AsyncClient(timeout=600, follow_redirects=True)
    try:
        req = client.build_request(
            method=request.method,
            url=url,
            content=request.stream(),
            headers={k: v for k, v in request.headers.items() if k.lower() not in ['host']},
            params=request.query_params,
        )
        resp = await client.send(req, stream=True)
    except Exception as e:
        await client.aclose()
        logger.error(f"Upload proxy error: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

    background_tasks.add_task(resp.aclose)
    background_tasks.add_task(client.aclose)

    return StreamingResponse(
        resp.aiter_bytes(),
        status_code=resp.status_code,
        media_type=resp.headers.get('content-type', 'application/octet-stream'),
    )

# ========== Duix 代理 ==========

@app.api_route("/easy/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def proxy_duix(path: str, request: Request):
    """代理 Duix 请求"""
    # 自动切换到 Duix
    if scheduler.current_service != 'duix':
        if scheduler.switching:
            return JSONResponse({"error": "Service switching in progress"}, status_code=503)
        
        success = scheduler.switch_to_service('duix')
        if not success:
            return JSONResponse({"error": "Failed to start Duix"}, status_code=500)
    
    # 转发请求
    url = f"{DUIX_URL}/easy/{path}"
    
    async with httpx.AsyncClient(timeout=300) as client:
        try:
            body = await request.body()
            resp = await client.request(
                method=request.method,
                url=url,
                content=body,
                headers={k: v for k, v in request.headers.items() if k.lower() not in ['host']},
                params=request.query_params,
            )
            
            # 返回原始响应
            return JSONResponse(
                resp.json() if resp.headers.get('content-type', '').startswith('application/json') else {"data": resp.text},
                status_code=resp.status_code
            )
        except Exception as e:
            logger.error(f"Duix proxy error: {e}")
            return JSONResponse({"error": str(e)}, status_code=500)

# 文件下载代理（Duix 视频下载）
@app.get("/download")
async def proxy_download(request: Request, background_tasks: BackgroundTasks):
    """代理 Duix 文件下载"""
    if scheduler.current_service != 'duix':
        if scheduler.switching:
            return JSONResponse({"error": "Service switching in progress"}, status_code=503)

        success = scheduler.switch_to_service('duix')
        if not success:
            return JSONResponse({"error": "Failed to start Duix"}, status_code=500)

    url = f"{DUIX_URL}/download"

    client = httpx.AsyncClient(timeout=600, follow_redirects=True)
    try:
        req = client.build_request('GET', url, params=request.query_params)
        resp = await client.send(req, stream=True)
    except Exception as e:
        await client.aclose()
        logger.error(f"Download proxy error: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)

    background_tasks.add_task(resp.aclose)
    background_tasks.add_task(client.aclose)

    return StreamingResponse(
        resp.aiter_bytes(),
        status_code=resp.status_code,
        media_type=resp.headers.get('content-type', 'application/octet-stream'),
        headers={
            'Content-Disposition': resp.headers.get('Content-Disposition', ''),
        }
    )

if __name__ == "__main__":
    logger.info("Starting GPU Service Scheduler on port 9999...")
    uvicorn.run(app, host="0.0.0.0", port=9999)
